package com.ig.service;

import com.ig.Dao.ScholarDao;
import com.ig.model.Scholar;
import com.exception.ScholarNotFoundException;
import java.util.List;

public class ScholarService {

    private ScholarDao scholarDao = new ScholarDao();


    public List<Scholar> listAllScholars() {
        return scholarDao.listAllScholars();
    }

   
    public Scholar getScholarById(int scholarId) throws ScholarNotFoundException {
        return scholarDao.getScholarById(scholarId);
    }


    public boolean updateScholarEmail(int scholarId, String newEmail) throws ScholarNotFoundException {
        return scholarDao.updateScholarEmail(scholarId, newEmail);
    }

   
    public boolean deleteScholarById(int scholarId) throws ScholarNotFoundException {
        return scholarDao.deleteScholarById(scholarId);
    }

    
    public boolean addScholar(Scholar scholar) {
        return scholarDao.addScholar(scholar);
    }
}

