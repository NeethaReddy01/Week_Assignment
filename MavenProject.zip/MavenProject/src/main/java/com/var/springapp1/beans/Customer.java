package com.var.springapp1.beans;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Customer implements InitializingBean,DisposableBean{
	String name;
	String email;
	public Customer(){
		
	}
	public Customer(String name, String email) {
		this.name = name;
		this.email = email;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", email=" + email + "]";
	}
	public void afterPropertiesSet() {
		System.out.println(" initialization of bean done");
	}
	public void destroy() {
		System.out.println(" destroying bean");
	}
}