package com.var.springapp1.beans;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.var.javaconfig.components.Bill;
public class AppTest {
	public static void main(String[] args) {
	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
        Customer c=(Customer)context.getBean(Customer.class);
        System.out.println(c   +"  "+c.hashCode());
        Customer c1=(Customer)context.getBean(Customer.class);
        System.out.println(c1  +"   "+c1.hashCode());
        context.close();
	}
}
