package com.igquery.service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.igquery.entity.Customer;
import com.igquery.exception.CustomerException;
import com.igquery.repository.CustomerRepository;

@Service(value = "customerService")
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public String findNameByEmailId(String emailId) {
		return customerRepository.findNameByEmailId(emailId);
	}

	@Override
	public void updateCustomerEmailId(String newEmailId, Integer customerId) throws CustomerException {
		Optional<Customer> optional = customerRepository.findById(customerId);
		optional.orElseThrow(() -> new CustomerException("Service.CUSTOMER_UNAVAILABLE"));
		customerRepository.updateCustomerEmailId(newEmailId, customerId);
		
	}

	@Override
	public void deleteCustomerByEmailId(String emailId) throws CustomerException {
		// Optional<CustomerEntity> customer = customerRespository.fi

		Integer count = customerRepository.deleteCustomerByEmailId(emailId);
		if (count == 0)
			throw new CustomerException("Service.CUSTOMER_UNAVAILABLE");
	}
}



/*
@Service(value = "customerService")
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository customerRepository;

	public CustomerDTO findByEmailId(String emailId) throws CustomerException {
		Optional<Customer> optional = customerRepository.findByEmailId(emailId);
		Customer customer = optional.orElseThrow(() -> new CustomerException("Service.CUSTOMER_UNAVAILABLE"));
			
		CustomerDTO customerDTO = new CustomerDTO();
		customerDTO.setCustomerId(customer.getCustomerId());
		customerDTO.setDateOfBirth(customer.getDateOfBirth());
		customerDTO.setEmailId(customer.getEmailId());
		customerDTO.setName(customer.getName());
		return customerDTO;
		
	}

	@Override
	public CustomerDTO findByEmailIdAndName(String emailId, String name) throws CustomerException {
		Optional<Customer> optional = customerRepository.findByEmailIdAndName(emailId, name);
		Customer customer = optional.orElseThrow(() -> new CustomerException("Service.CUSTOMER_UNAVAILABLE"));
		
		CustomerDTO customerDTO = new CustomerDTO();
		customerDTO.setCustomerId(customer.getCustomerId());
		customerDTO.setDateOfBirth(customer.getDateOfBirth());
		customerDTO.setEmailId(customer.getEmailId());
		customerDTO.setName(customer.getName());
		return customerDTO;
	}

	@Override
	public List<CustomerDTO> findByEmailIdOrName(String emailId, String name) throws CustomerException {
		List<Customer> customers = customerRepository.findByEmailIdOrName(emailId, name);
		List<CustomerDTO> customerDTOs = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("Service.CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
			CustomerDTO customerDTO = new CustomerDTO();
			customerDTO.setCustomerId(customer.getCustomerId());
			customerDTO.setDateOfBirth(customer.getDateOfBirth());
			customerDTO.setEmailId(customer.getEmailId());
			customerDTO.setName(customer.getName());
			customerDTOs.add(customerDTO);
		});
		return customerDTOs;
	}

	@Override
	public List<CustomerDTO> findByDateOfBirthBetween(LocalDate fromDate, LocalDate toDate) throws CustomerException {
		List<Customer> customers = customerRepository.findByDateOfBirthBetween(fromDate, toDate);
		List<CustomerDTO> customerDTOs = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("Service.CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
			CustomerDTO customerDTO = new CustomerDTO();
			customerDTO.setCustomerId(customer.getCustomerId());
			customerDTO.setDateOfBirth(customer.getDateOfBirth());
			customerDTO.setEmailId(customer.getEmailId());
			customerDTO.setName(customer.getName());
			customerDTOs.add(customerDTO);
		});
		return customerDTOs;
	}

	@Override
	public List<CustomerDTO> findByDateOfBirthLessThan(LocalDate dateOfBirth) throws CustomerException {
		List<Customer> customers = customerRepository.findByDateOfBirthLessThan(dateOfBirth);
		List<CustomerDTO> customerDTOs = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("Service.CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
			CustomerDTO customerDTO = new CustomerDTO();
			customerDTO.setCustomerId(customer.getCustomerId());
			customerDTO.setDateOfBirth(customer.getDateOfBirth());
			customerDTO.setEmailId(customer.getEmailId());
			customerDTO.setName(customer.getName());
			customerDTOs.add(customerDTO);
		});
		return customerDTOs;
	}

	@Override
	public List<CustomerDTO> findByDateOfBirthGreaterThan(LocalDate dateOfBirth) throws CustomerException {
		List<Customer> customers = customerRepository.findByDateOfBirthGreaterThan(dateOfBirth);
		List<CustomerDTO> customerDTOs = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("Service.CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
			CustomerDTO customerDTO = new CustomerDTO();
			customerDTO.setCustomerId(customer.getCustomerId());
			customerDTO.setDateOfBirth(customer.getDateOfBirth());
			customerDTO.setEmailId(customer.getEmailId());
			customerDTO.setName(customer.getName());
			customerDTOs.add(customerDTO);
		});
		return customerDTOs;
	}

	@Override
	public List<CustomerDTO> findByDateOfBirthAfter(LocalDate dateOfBirth) throws CustomerException {
		List<Customer> customers = customerRepository.findByDateOfBirthAfter(dateOfBirth);
		List<CustomerDTO> customerDTOs = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("Service.CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
			CustomerDTO customerDTO = new CustomerDTO();
			customerDTO.setCustomerId(customer.getCustomerId());
			customerDTO.setDateOfBirth(customer.getDateOfBirth());
			customerDTO.setEmailId(customer.getEmailId());
			customerDTO.setName(customer.getName());
			customerDTOs.add(customerDTO);
		});
		return customerDTOs;
	}

	@Override
	public List<CustomerDTO> findByDateOfBirthBefore(LocalDate dateOfBirth) throws CustomerException {
		List<Customer> customers = customerRepository.findByDateOfBirthBefore(dateOfBirth);
		List<CustomerDTO> customerDTOs = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("Service.CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
			CustomerDTO customerDTO = new CustomerDTO();
			customerDTO.setCustomerId(customer.getCustomerId());
			customerDTO.setDateOfBirth(customer.getDateOfBirth());
			customerDTO.setEmailId(customer.getEmailId());
			customerDTO.setName(customer.getName());
			customerDTOs.add(customerDTO);
		});
		return customerDTOs;
	}

	@Override
	public List<CustomerDTO> findByEmailIdNull() throws CustomerException {
		List<Customer> customers = customerRepository.findByEmailIdNull();
		List<CustomerDTO> customerDTOs = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("Service.CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
			CustomerDTO customerDTO = new CustomerDTO();
			customerDTO.setCustomerId(customer.getCustomerId());
			customerDTO.setDateOfBirth(customer.getDateOfBirth());
			customerDTO.setEmailId(customer.getEmailId());
			customerDTO.setName(customer.getName());
			customerDTOs.add(customerDTO);
		});
		return customerDTOs;
	}

	@Override
	public List<CustomerDTO> findByNameLike(String pattern) throws CustomerException {
		List<Customer> customers = customerRepository.findByNameLike(pattern);
		List<CustomerDTO> customerDTOs = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("Service.CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
			CustomerDTO customerDTO = new CustomerDTO();
			customerDTO.setCustomerId(customer.getCustomerId());
			customerDTO.setDateOfBirth(customer.getDateOfBirth());
			customerDTO.setEmailId(customer.getEmailId());
			customerDTO.setName(customer.getName());
			customerDTOs.add(customerDTO);
		});
		return customerDTOs;
	}

	@Override
	public List<CustomerDTO> findByNameOrderByDateOfBirth(String name) throws CustomerException {
		List<Customer> customers = customerRepository.findByNameOrderByDateOfBirth(name);
		List<CustomerDTO> customerDTOs = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("Service.CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
			CustomerDTO customerDTO = new CustomerDTO();
			customerDTO.setCustomerId(customer.getCustomerId());
			customerDTO.setDateOfBirth(customer.getDateOfBirth());
			customerDTO.setEmailId(customer.getEmailId());
			customerDTO.setName(customer.getName());
			customerDTOs.add(customerDTO);
		});
		return customerDTOs;
	}

	@Override
	public List<CustomerDTO> findByNameOrderByDateOfBirthDesc(String name) throws CustomerException {
		List<Customer> customers = customerRepository.findByNameOrderByDateOfBirthDesc(name);
		List<CustomerDTO> customerDTOs = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("Service.CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
			CustomerDTO customerDTO = new CustomerDTO();
			customerDTO.setCustomerId(customer.getCustomerId());
			customerDTO.setDateOfBirth(customer.getDateOfBirth());
			customerDTO.setEmailId(customer.getEmailId());
			customerDTO.setName(customer.getName());
			customerDTOs.add(customerDTO);
		});
		return customerDTOs;
	}
}
*/