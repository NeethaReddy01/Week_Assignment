package com.ig.model;

import com.ig.exception.InvalidAmountException;
import com.ig.exception.LowBalanceException;

public class Account {
    public enum AccountType {
        SAVINGS, CURRENT
    }

    private Integer accNumber;
    private String custName;
    private AccountType type;
    private Float balance;

    public Account(Integer accNumber, String custName, AccountType type, Float balance) throws InvalidAmountException, LowBalanceException {
        if (balance < 0) {
            throw new InvalidAmountException("Initial balance is not negative");
        }
        if (type == AccountType.SAVINGS && balance < 1000) {
            throw new LowBalanceException("Initial balance for savings account should not be less than 1000");
        }
        if (type == AccountType.CURRENT && balance < 5000) {
            throw new LowBalanceException("Initial balance for current account should not be less than 5000");
        }
        this.accNumber = accNumber;
        this.custName = custName;
        this.type = type;
        this.balance = balance;
    }

    public Integer getAccNumber() {
        return accNumber;
    }

    public String getCustName() {
        return custName;
    }

    public AccountType getType() {
        return type;
    }

    public Float getBalance() {
        return balance;
    }

    public void setBalance(Float balance) {
        this.balance = balance;
    }
}
