package com.ig.service;

import com.ig.model.Account;
import com.ig.exception.*;

import java.util.ArrayList;
import java.util.List;

public class AccountService {
    private List<Account> accountList = new ArrayList<>();

    public boolean isValidAccount(int accNumber) throws AccountNotFoundException {
        return accountList.stream().anyMatch(account -> account.getAccNumber().equals(accNumber));
    }

    public void deposit(int accNumber, float amt) throws AccountNotFoundException, InvalidAmountException {
        Account account = findAccount(accNumber);
        if (amt < 0) {
            throw new InvalidAmountException("Amount to deposit cannot be negative");
        }
        account.setBalance(account.getBalance() + amt);
    }

    public void withdraw(int accNumber, float amt) throws AccountNotFoundException, InvalidAmountException, InsufficientFundsException {
        Account account = findAccount(accNumber);
        if (amt < 500) {
            throw new InvalidAmountException("Minimum amount to withdraw is 500");
        }
        float newBalance = account.getBalance() - amt;
        if (account.getType() == Account.AccountType.SAVINGS && newBalance < 1000) {
            throw new InsufficientFundsException("Insufficient funds for savings account");
        }
        if (account.getType() == Account.AccountType.CURRENT && newBalance < 5000) {
            throw new InsufficientFundsException("Insufficient funds for current account");
        }
        account.setBalance(newBalance);
    }

    public float getBalance(int accNumber) throws AccountNotFoundException {
        return findAccount(accNumber).getBalance();
    }

    private Account findAccount(int accNumber) throws AccountNotFoundException {
        return accountList.stream()
                .filter(account -> account.getAccNumber().equals(accNumber))
                .findFirst()
                .orElseThrow(() -> new AccountNotFoundException("Account not found"));
    }

    public void addAccount(Account account) {
        accountList.add(account);
    }
}
