package com.ig.ui;

import com.ig.model.Account;
import com.ig.service.AccountService;
import com.ig.exception.*;

public class AccountTest {
    public static void main(String[] args) {
        AccountService service = new AccountService();
        try {
            service.addAccount(new Account(1, "Alice", Account.AccountType.SAVINGS, 2000f));
            service.addAccount(new Account(2, "Bob", Account.AccountType.CURRENT, 6000f));
            service.addAccount(new Account(3, "Charlie", Account.AccountType.SAVINGS, 1500f));
            service.addAccount(new Account(4, "Dave", Account.AccountType.CURRENT, 7000f));
            service.addAccount(new Account(5, "Eve", Account.AccountType.SAVINGS, 3000f));

            System.out.println("Balance of Account 4 is : " + service.getBalance(4));
            service.deposit(4, 500);
            System.out.println("Balance of Account 4 after deposit is : " + service.getBalance(4));
            service.withdraw(4, 1000);
            System.out.println("Balance of Account 4 after withdrawal is : " + service.getBalance(4));

        } catch (AccountNotFoundException | InvalidAmountException | InsufficientFundsException | LowBalanceException e) {
            System.out.println(e.getMessage());
        }
    }
}
