package com.ig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecuritydemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
