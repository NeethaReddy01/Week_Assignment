package com.ig.autowiring.repository;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;
import com.ig.autowiring.model.Product;

@Component
public class ProductRepo {
    static List<Product> plist = new ArrayList<>();
    static {
        plist.add(new Product(10, "pen"));
        plist.add(new Product(20, "bag"));
        plist.add(new Product(30, "tin"));
    }

    public void addProduct(Product product) {
        plist.add(product);
    }

    public Product getProduct(Integer id) {
        for (Product p : plist) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null;        
    }

    public List<Product> getAllProducts() {
        return plist;
    }
}
