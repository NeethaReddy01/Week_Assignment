package com.ig.autowiring.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ig.autowiring.model.Product;
import com.ig.autowiring.repository.ProductRepo;

@Service
public class ProductService {

    @Autowired
    private ProductRepo productRepo;

    public void addProduct(Product product) {
        productRepo.addProduct(product);
    }

    public Product getProduct(Integer id) {
        return productRepo.getProduct(id);
    }

    public List<Product> getAllProducts() {
        return productRepo.getAllProducts();
    }
}
