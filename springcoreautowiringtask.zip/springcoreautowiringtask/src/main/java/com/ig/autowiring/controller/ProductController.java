package com.ig.autowiring.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.ig.autowiring.model.Product;
import com.ig.autowiring.service.ProductService;

@RestController
public class ProductController {

    @Autowired
    private ProductService productService;

    
    @GetMapping("/products")  //all products
    public List<Product> getAllProducts() {
        return productService.getAllProducts();
    }

    
    @GetMapping("/product/{id}") //single product id
    public Product getProduct(@PathVariable("id") Integer id) {
        return productService.getProduct(id);
    }

    
    @PostMapping("/product")  //adding new product
    public String addProduct(@RequestBody Product product) {
        productService.addProduct(product);
        return "Product added successfully!";
    }
}
