package com.ig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringcoreautowiringtaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringcoreautowiringtaskApplication.class, args);
	}

}
