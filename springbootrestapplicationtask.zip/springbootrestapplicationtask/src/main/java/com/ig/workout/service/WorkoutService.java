package com.ig.workout.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ig.workout.exception.WorkoutNotFoundException;
import com.ig.workout.model.Workout;
import com.ig.workout.repository.WorkoutRepository;

@Service
public class WorkoutService {
	@Autowired
	WorkoutRepository workoutRepo;
	
	public Workout addWorkout(Workout workout) {
        return workoutRepo.save(workout);
    }

    public List<Workout> getAllWorkouts() {
        return (List)workoutRepo.findAll();
    }
    
    public Workout getWorkoutById(Integer id) {
        return workoutRepo.findById(id)
                .orElseThrow(() -> new WorkoutNotFoundException("Workout not found"));
    }

}
