package com.ig.workout.client;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.ig.workout.model.Workout;

@Component
public class WorkoutClient {

    private final RestTemplate restTemplate = new RestTemplate();
    private final String BASE_URL = "http://localhost:8090/api/workouts";

    public Workout addWorkout(Workout workout) {
        return restTemplate.postForObject(BASE_URL, workout, Workout.class);
    }

    public List<Workout> getAllWorkouts() {
        return Arrays.asList(restTemplate.getForObject(BASE_URL, Workout[].class));
    }
}

