package com.ig.workout.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ig.workout.model.Workout;

//import com.ig.workout.model.Workout;

@Repository
public interface WorkoutRepository extends CrudRepository<Workout,Integer> {
	//all methods available in CrudRepository can be called directly in service.

}
