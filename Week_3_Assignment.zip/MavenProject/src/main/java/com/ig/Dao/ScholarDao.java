package com.ig.Dao;

import com.ig.model.Scholar;
import com.exception.ScholarNotFoundException;
import com.ig.util.DbUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ScholarDao {

    public boolean addScholar(Scholar scholar) {
        String query = "INSERT INTO Scholar (Rollno, Name, Email, Mobile) VALUES (?, ?, ?, ?)";
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, scholar.getRollno());
            preparedStatement.setString(2, scholar.getName());
            preparedStatement.setString(3, scholar.getEmail());
            preparedStatement.setString(4, scholar.getMobile());

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

  
    public Scholar getScholarById(int rollno) throws ScholarNotFoundException {
        String query = "SELECT * FROM Scholar WHERE Rollno = ?";
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, rollno);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return new Scholar(resultSet.getInt("Rollno"),
                                   resultSet.getString("Name"),
                                   resultSet.getString("Email"),
                                   resultSet.getString("Mobile"));
            } else {
                throw new ScholarNotFoundException("Scholar with Rollno " + rollno + " not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

   
    public boolean updateScholarEmail(int rollno, String newEmail) throws ScholarNotFoundException {
        String query = "UPDATE Scholar SET Email = ? WHERE Rollno = ?";
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, newEmail);
            preparedStatement.setInt(2, rollno);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                return true;
            } else {
                throw new ScholarNotFoundException("Scholar with Rollno " + rollno + " not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

   
    public boolean deleteScholarById(int rollno) throws ScholarNotFoundException {
        String query = "DELETE FROM Scholar WHERE Rollno = ?";
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, rollno);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                return true;
            } else {
                throw new ScholarNotFoundException("Scholar with Rollno " + rollno + " not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Scholar> listAllScholars() {
        List<Scholar> scholars = new ArrayList<>();
        String query = "SELECT * FROM Scholar";
        try (Connection connection = DbUtil.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                scholars.add(new Scholar(resultSet.getInt("Rollno"),resultSet.getString("Name"),resultSet.getString("Email"),resultSet.getString("Mobile")));
            }
            return scholars;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
