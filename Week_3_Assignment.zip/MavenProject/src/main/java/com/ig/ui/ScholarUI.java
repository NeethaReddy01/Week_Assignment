package com.ig.ui;

import com.ig.model.Scholar;
import com.ig.service.ScholarService;
import com.exception.ScholarNotFoundException;
import java.util.List;
import java.util.Scanner;

public class ScholarUI {
    private ScholarService scholarService = new ScholarService();
    private Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        while (true) {
            System.out.println("Scholar Management System:");
            System.out.println("1. Add Scholar");
            System.out.println("2. List All Scholars");
            System.out.println("3. Get Scholar by ID");
            System.out.println("4. Update Scholar Email");
            System.out.println("5. Delete Scholar by ID");
            System.out.println("6. Exit");

            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    addScholar();
                    break;
                case 2:
                    listAllScholars();
                    break;
                case 3:
                    getScholarById();
                    break;
                case 4:
                    updateScholarEmail();
                    break;
                case 5:
                    deleteScholarById();
                    break;
                case 6:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    public void addScholar() {
        System.out.print("Enter Rollno: ");
        int rollno = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Enter Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Email: ");
        String email = scanner.nextLine();

        System.out.print("Enter Mobile: ");
        String mobile = scanner.nextLine();

        Scholar scholar = new Scholar(rollno, name, email, mobile);
        if (scholarService.addScholar(scholar)) {
            System.out.println("Scholar added successfully!");
        } else {
            System.out.println("Failed to add scholar.");
        }
    }

    public void listAllScholars() {
        List<Scholar> scholars = scholarService.listAllScholars();
        if (scholars != null && !scholars.isEmpty()) {
            for (Scholar scholar : scholars) {
                System.out.println("Rollno: " + scholar.getRollno() + ", Name: " + scholar.getName() +
                        ", Email: " + scholar.getEmail() + ", Mobile: " + scholar.getMobile());
            }
        } else {
            System.out.println("No scholars found.");
        }
    }

    public void getScholarById() {
        System.out.print("Enter Scholar Rollno: ");
        int scholarId = scanner.nextInt();

        try {
            Scholar scholar = scholarService.getScholarById(scholarId);
            System.out.println("Rollno: " + scholar.getRollno() + ", Name: " + scholar.getName() +
                    ", Email: " + scholar.getEmail() + ", Mobile: " + scholar.getMobile());
        } catch (ScholarNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    public void updateScholarEmail() {
        System.out.print("Enter Scholar Rollno: ");
        int scholarId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Enter new Email: ");
        String newEmail = scanner.nextLine();

        try {
            if (scholarService.updateScholarEmail(scholarId, newEmail)) {
                System.out.println("Email updated successfully.");
            } else {
                System.out.println("Failed to update email.");
            }
        } catch (ScholarNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    public void deleteScholarById() {
        System.out.print("Enter Scholar Rollno: ");
        int scholarId = scanner.nextInt();

        try {
            if (scholarService.deleteScholarById(scholarId)) {
                System.out.println("Scholar deleted successfully.");
            } else {
                System.out.println("Failed to delete scholar.");
            }
        } catch (ScholarNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        ScholarUI scholarUI = new ScholarUI();
        scholarUI.displayMenu();
    }
}
