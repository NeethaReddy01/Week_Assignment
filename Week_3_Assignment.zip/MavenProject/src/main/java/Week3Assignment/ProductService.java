package Week3Assignment;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class ProductService {

 
    private List<Product> products = new ArrayList<>();

    public ProductService(List<Product> products) {
        this.products = products;
    }
  
    public Optional<Product> getHighestPricedProduct() {
        return products.stream()
                .max(Comparator.comparing(Product::getPrice));
    }
   
    public Optional<Product> getLowestPricedProduct() {
        return products.stream()
                .min(Comparator.comparing(Product::getPrice));
    }
    
    public List<Product> getExpiredProducts() {
        return products.stream()
                .filter(product -> product.getExpiryDate().isBefore(LocalDate.now()))
                .collect(Collectors.toList());
    }

   
    public List<String> getProductsExpiringInNext10Days() {
        LocalDate now = LocalDate.now();
        LocalDate tenDaysLater = now.plusDays(10);

        return products.stream()
                .filter(product -> !product.getExpiryDate().isBefore(now) && product.getExpiryDate().isBefore(tenDaysLater))
                .map(Product::getName)
                .collect(Collectors.toList());
    }
   
    public Map<String, Long> getCountByProductType() {
        return products.stream()
                .collect(Collectors.groupingBy(Product::getType, Collectors.counting()));
    }

    public Map<String, Long> getCountBySupplier() {
        return products.stream()
                .collect(Collectors.groupingBy(product -> product.getSupplier().getSname(), Collectors.counting()));
    }
   
    public static void main(String[] args) {
        // Creating sample suppliers
        Supplier supplier1 = new Supplier(1, "Supplier1");
        Supplier supplier2 = new Supplier(2, "Supplier2");

     
        List<Product> productList = Arrays.asList(
                new Product(1, "Oil", "Oils", 10.0, 50.0, LocalDate.of(2023, 6, 15), supplier1),
                new Product(2, "Snacks", "Snacks", 5.0, 20.0, LocalDate.of(2023, 4, 1), supplier1),
                new Product(3, "Milk", "Dairy", 7.0, 80.0, LocalDate.of(2023, 3, 25), supplier2),
                new Product(4, "Rice", "Pulses", 15.0, 30.0, LocalDate.of(2023, 9, 10), supplier2),
                new Product(5, "Sugar", "Pulses", 3.0, 10.0, LocalDate.of(2025, 3, 10), supplier1)
        );

        ProductService productService = new ProductService(productList);

     
        System.out.println("Highest priced product: " + productService.getHighestPricedProduct().orElse(null));
        
        System.out.println();
      
        System.out.println("Lowest priced product: " + productService.getLowestPricedProduct().orElse(null));
        
        System.out.println();

        System.out.println("Expired products: " + productService.getExpiredProducts());

        System.out.println();
       
        System.out.println("Products expiring in next 10 days: " + productService.getProductsExpiringInNext10Days());

        System.out.println();
        
        System.out.println("Product count by type: " + productService.getCountByProductType());

        System.out.println();
        
        System.out.println("Product count by supplier: " + productService.getCountBySupplier());
    }
}

