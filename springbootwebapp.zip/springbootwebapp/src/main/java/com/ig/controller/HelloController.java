package com.ig.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
	
	@GetMapping("/welcome")  
	public String getWelcomeMessage() {
		return "Welcome to SpringBoot Web Application!!!!!";
	}

	@GetMapping("/hello") 
	public String getHelloMessage() {
		return "Hello!!!!!!!";
	}

}


//http://localhost:8082/welcome
//http://localhost:8082/hello